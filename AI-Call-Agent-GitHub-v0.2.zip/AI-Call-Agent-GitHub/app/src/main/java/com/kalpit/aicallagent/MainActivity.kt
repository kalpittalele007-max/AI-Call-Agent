package com.kalpit.aicallagent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                CallAgentScreen(
                    onPrepareCall = { number ->
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                        startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
private fun CallAgentScreen(onPrepareCall: (String) -> Unit) {
    var phoneNumber by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "AI Call Agent",
                style = MaterialTheme.typography.headlineMedium
            )

            Text(
                text = "Plan an AI-assisted call. The agent will identify itself as an AI before any automated conversation features are enabled.",
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text("Phone number") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text("Reason / instructions") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val number = phoneNumber.trim()
                    if (number.isEmpty()) {
                        status = "Enter a phone number first."
                    } else {
                        status = "Opening the supported Android dialer..."
                        onPrepareCall(number)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Prepare Call")
            }

            HorizontalDivider()

            Text("Status: $status")
            Text("Conversation engine: Not connected")
            Text("Speech recognition: Not connected")
            Text("Text-to-speech: Not connected")
            Text("Call automation: Not enabled")
        }
    }
}
