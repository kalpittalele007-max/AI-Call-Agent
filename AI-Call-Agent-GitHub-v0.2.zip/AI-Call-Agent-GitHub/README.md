# AI Call Agent

An independent Android project for an AI-assisted calling agent.

## Current version

The first milestone provides:

- Basic Android UI
- Phone-number input
- Reason/instructions field
- Supported Android dialer launch
- Initial project structure
- GitHub Actions debug-APK build

The autonomous conversation engine is intentionally not enabled yet.

## Planned architecture

1. Call preparation
2. Contact selection
3. Speech recognition
4. AI conversation engine
5. Text-to-speech
6. Call-state handling
7. Conversation/session controls
8. Permissions and safety controls
9. Testing and logging

Automated calling and conversation features will be added as separate milestones rather than being mixed into the initial UI.

## GitHub Actions

Every push to `main` and every pull request runs the Android debug build.

The generated APK is uploaded as the workflow artifact:

`ai-call-agent-debug-apk`
