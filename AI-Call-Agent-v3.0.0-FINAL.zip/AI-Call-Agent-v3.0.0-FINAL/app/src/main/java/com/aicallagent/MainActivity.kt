package com.aicallagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var phone by mutableStateOf("")
    private var reason by mutableStateOf("")
    private var objective by mutableStateOf("")
    private var contextInfo by mutableStateOf("")
    private var instructions by mutableStateOf("")
    private var completion by mutableStateOf("")
    private var status by mutableStateOf("Ready")
    private var transcript by mutableStateOf(listOf<String>())

    private var tts: TextToSpeech? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            status = "Permissions updated"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }

        setContent {
            MaterialTheme {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("AI Call Agent", style = MaterialTheme.typography.headlineMedium)
                    Text("AI-assisted call planning and conversation prototype")

                    Field("Phone number", phone) { phone = it }
                    Field("Reason for calling", reason) { reason = it }
                    Field("Objective", objective) { objective = it }
                    Field("Allowed information", contextInfo) { contextInfo = it }
                    Field("Additional instructions", instructions) { instructions = it }
                    Field("Completion condition", completion) { completion = it }

                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("AI disclosure")
                            Spacer(Modifier.height(4.dp))
                            Text("The agent must identify itself as an AI to the person being contacted.")
                        }
                    }

                    Text("Status: $status")

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { prepareSession() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Prepare")
                        }

                        OutlinedButton(
                            onClick = { openDialer() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Open Dialer")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { launchSpeechInput() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Speech Input")
                        }

                        OutlinedButton(
                            onClick = {
                                tts?.speak(
                                    "Hello. I am an AI call agent calling regarding ${reason.ifBlank { "the stated matter" }}.",
                                    TextToSpeech.QUEUE_FLUSH,
                                    null,
                                    "agent-opening"
                                )
                                status = "Speaking test response"
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("TTS Test")
                        }
                    }

                    if (transcript.isNotEmpty()) {
                        Text("Conversation")
                        transcript.forEach {
                            Text(it, modifier = Modifier.padding(vertical = 2.dp))
                        }
                    }

                    Text(
                        "Phone-call audio integration is intentionally not faked. Android/device telephony capabilities determine whether an external call can be connected to an AI conversation."
                    )
                }
            }
        }
    }

    @androidx.compose.runtime.Composable
    private fun Field(
        label: String,
        value: String,
        onValueChange: (String) -> Unit
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
            minLines = if (label.contains("information", true) || label.contains("instructions", true)) 3 else 1
        )
    }

    private fun prepareSession() {
        if (objective.isBlank()) {
            status = "Enter an objective first"
            return
        }

        val plan = CallPlan(
            phoneNumber = phone.trim(),
            reason = reason.trim(),
            objective = objective.trim(),
            allowedInformation = contextInfo.trim(),
            instructions = instructions.trim(),
            completionCondition = completion.trim()
        )

        status = "Session prepared"
        transcript = listOf(
            "SYSTEM: Objective = ${plan.objective}",
            "SYSTEM: Completion = ${plan.completionCondition.ifBlank { "Not specified" }}"
        )
    }

    private fun openDialer() {
        if (phone.isBlank()) {
            status = "Enter a phone number first"
            return
        }

        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone.trim())}"))
        startActivity(intent)
        status = "Opened system dialer"
    }

    private fun launchSpeechInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak the person's response")
        }
        runCatching {
            startActivityForResult(intent, SPEECH_REQUEST)
        }.onFailure {
            status = "Speech recognition unavailable"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST && resultCode == Activity.RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = results?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                transcript = transcript + "PERSON: $text"
                status = "Speech captured"
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val SPEECH_REQUEST = 1001
    }
}
