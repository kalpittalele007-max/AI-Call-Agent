package com.aicallagent

import android.app.Service
import android.content.Intent
import android.os.IBinder
import java.util.concurrent.CopyOnWriteArrayList

enum class SessionState {
    IDLE, PREPARING, CALL_REQUESTED, RINGING, CONNECTED,
    LISTENING, THINKING, SPEAKING, INTERRUPTED,
    OBJECTIVE_CHECK, ENDING, ENDED, ERROR
}

data class CallPlan(
    val phoneNumber: String,
    val reason: String,
    val objective: String,
    val allowedInformation: String,
    val instructions: String,
    val completionCondition: String
)

data class ConversationTurn(
    val speaker: String,
    val text: String
)

interface AiConversationEngine {
    suspend fun respond(
        plan: CallPlan,
        history: List<ConversationTurn>,
        latestPersonText: String
    ): String
}

interface SpeechRecognizerEngine {
    fun startListening(onResult: (String) -> Unit, onError: (String) -> Unit)
    fun stopListening()
}

interface SpeechSynthesizerEngine {
    fun speak(text: String, onDone: () -> Unit, onError: (String) -> Unit)
    fun stop()
}

interface CallController {
    fun prepareCall(plan: CallPlan)
    fun startCall(): Boolean
    fun endCall(): Boolean
}

class SafePlaceholderAiEngine : AiConversationEngine {
    override suspend fun respond(
        plan: CallPlan,
        history: List<ConversationTurn>,
        latestPersonText: String
    ): String {
        return "I received your response. This build is ready for a real AI provider to be connected securely."
    }
}

class CallAgentService : Service() {

    private var state: SessionState = SessionState.IDLE
    private var currentPlan: CallPlan? = null
    private val history = CopyOnWriteArrayList<ConversationTurn>()

    override fun onBind(intent: Intent?): IBinder? = null

    fun prepare(plan: CallPlan) {
        currentPlan = plan
        history.clear()
        state = SessionState.PREPARING
    }

    fun addTurn(speaker: String, text: String) {
        history.add(ConversationTurn(speaker, text))
    }

    fun getHistory(): List<ConversationTurn> = history.toList()

    fun getState(): SessionState = state

    fun setState(newState: SessionState) {
        state = newState
    }

    override fun onDestroy() {
        state = SessionState.ENDED
        super.onDestroy()
    }
}
