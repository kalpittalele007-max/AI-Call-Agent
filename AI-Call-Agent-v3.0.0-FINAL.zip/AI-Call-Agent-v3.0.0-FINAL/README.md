# AI Call Agent v3.0.0

AI-assisted phone-call planning and conversation prototype for Android.

## What is implemented

- Modern Android UI
- Phone number and call-objective configuration
- Reason/context/instructions/completion-condition fields
- AI disclosure requirement
- Session state model
- Conversation history model
- AI provider abstraction
- Speech recognition through Android's supported speech intent
- Android Text-to-Speech
- System dialer launch
- Safe fallback AI implementation
- GitHub Actions build workflow

## Important telephony limitation

A normal third-party Android application cannot arbitrarily capture or inject audio into cellular phone calls. This project therefore does not pretend to implement hidden call-audio interception.

The application opens the supported Android system dialer and provides the architecture needed to connect an AI conversation layer when the target device/Android role/API legitimately supports the required telephony/audio routing.

## Real AI provider

`AiConversationEngine` is the provider boundary.

Do not place API keys in the Android APK. For a real deployment, use a secure backend:

Android -> HTTPS backend -> AI provider -> Android

The included `SafePlaceholderAiEngine` intentionally does not pretend to be a real LLM.

## Build

With the Gradle wrapper:

```bash
./gradlew assembleDebug --no-daemon
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

The workflow at `.github/workflows/android.yml` builds the debug APK and uploads it as an artifact.

## Safety and privacy

- No hidden call recording.
- No secret cellular-call interception.
- No API keys in source.
- The AI must identify itself as AI.
- Conversation data should be minimized and protected when a real backend is added.

## Status

This is an integration-ready prototype. Full autonomous cellular-call conversation requires Android/device telephony capabilities that are not universally available to ordinary applications.
