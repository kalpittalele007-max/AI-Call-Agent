package com.kalpit.aicallagent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                CallAgentScreen(
                    onStartCall = { number ->
                        // Version 1 deliberately uses Android's supported dial/call flow.
                        // Autonomous AI conversation will be added in later milestones.
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                        startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun CallAgentScreen(onStartCall: (String) -> Unit) {
    var contact by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("AI Call Agent", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Prepare an AI-assisted call. The agent will identify itself as an AI.",
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = contact,
                onValueChange = { contact = it },
                label = { Text("Phone number") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text("Reason / instructions") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (contact.isBlank()) {
                        status = "Enter a phone number first."
                    } else {
                        status = "Opening supported calling interface..."
                        onStartCall(contact.trim())
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Prepare Call")
            }

            HorizontalDivider()

            Text("Status: $status")
            Text("Conversation engine: Not connected yet")
            Text("Speech recognition: Not connected yet")
            Text("Text-to-speech: Not connected yet")
        }
    }
}
