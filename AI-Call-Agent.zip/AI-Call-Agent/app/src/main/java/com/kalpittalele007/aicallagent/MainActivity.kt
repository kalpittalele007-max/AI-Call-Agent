package com.kalpittalele007.aicallagent

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var pendingCallNumber: String? = null
    private var pendingStart = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val number = pendingCallNumber ?: return@registerForActivityResult
        if (grants[Manifest.permission.CALL_PHONE] == true || hasPermission(Manifest.permission.CALL_PHONE)) {
            placePreparedCall(number)
        } else {
            statusMessage = "Phone-call permission is required to place the call."
            pendingStart = false
        }
    }

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (pendingStart && isDefaultDialer()) {
            pendingStart = false
            placePreparedCall(pendingCallNumber.orEmpty())
        } else if (pendingStart) {
            pendingStart = false
            statusMessage = "AI Call Agent must be the default phone app before it can provide supported call control."
        }
    }

    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) contactPicker.launch(null)
        else statusMessage = "Contacts permission is needed only to read the selected contact's phone number."
    }

    private val contactPicker = registerForActivityResult(
        ActivityResultContracts.PickContact()
    ) { uri ->
        if (uri != null) {
            val number = readFirstPhoneNumber(uri)
            if (number != null) selectedNumber = number
            else statusMessage = "The selected contact has no phone number available."
        }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(CallAgentService.EXTRA_STATE) ?: return
            val message = intent.getStringExtra(CallAgentService.EXTRA_MESSAGE)
            statusMessage = message ?: state
        }
    }

    private var selectedNumber by mutableStateOf("")
    private var statusMessage by mutableStateOf("IDLE — ready to prepare a call")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(color = MaterialTheme.colorScheme.background) {
                CallAgentScreen()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            IntentFilter(CallAgentService.ACTION_STATUS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        unregisterReceiver(statusReceiver)
        super.onStop()
    }

    @androidx.compose.runtime.Composable
    private fun CallAgentScreen() {
        val context = LocalContext.current
        var reason by remember { mutableStateOf("") }
        var information by remember { mutableStateOf("") }
        var instructions by remember { mutableStateOf("") }
        var discloseAi by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf<String?>(null) }

        Scaffold { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("AI Call Agent", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Prepare a transparent AI-assisted call session. The agent must identify itself as AI.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Person", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = selectedNumber,
                            onValueChange = { selectedNumber = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Phone number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true
                        )
                        OutlinedButton(
                            onClick = {
                                if (hasPermission(Manifest.permission.READ_CONTACTS)) contactPicker.launch(null)
                                else contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Choose contact") }
                        Text(
                            "Contacts access is requested only to read the phone number of the contact you select.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Reason for calling") },
                    minLines = 2
                )

                OutlinedTextField(
                    value = information,
                    onValueChange = { information = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Information the AI may use") },
                    minLines = 3
                )

                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Conversation instructions (optional)") },
                    minLines = 3
                )

                Card(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = discloseAi, onCheckedChange = { discloseAi = it })
                        Column(Modifier.weight(1f)) {
                            Text("Identify as AI agent", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Recommended and required for transparent interaction.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Text(
                    "Phone permission is requested only when you press the start button. Microphone access is not requested because ordinary cellular-call audio is not exposed to this app.",
                    style = MaterialTheme.typography.bodySmall
                )

                Text("Status", style = MaterialTheme.typography.titleMedium)
                Text(statusMessage, style = MaterialTheme.typography.bodyMedium)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

                Button(
                    onClick = {
                        error = null
                        val number = selectedNumber.trim()
                        if (number.isBlank()) {
                            error = "Enter a phone number or choose a contact."
                            return@Button
                        }
                        if (reason.isBlank()) {
                            error = "Enter a reason for the call."
                            return@Button
                        }
                        if (!discloseAi) {
                            error = "The AI identity disclosure cannot be disabled."
                            return@Button
                        }

                        val plan = CallPlan(
                            person = number,
                            reason = reason.trim(),
                            information = information.trim(),
                            instructions = instructions.trim(),
                            discloseAi = true
                        )
                        pendingCallNumber = number
                        CallAgentService.prepareSession(context, plan)
                        statusMessage = "PREPARING — validating permissions and supported call controls"
                        beginCall(number)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Prepare & start supported call") }

                Spacer(Modifier.height(8.dp))
                Text(
                    "Important: standard Android cellular calling does not give ordinary apps arbitrary access to the remote call audio. This app never attempts to bypass that restriction. Live AI conversation requires a supported telephony/VoIP integration that supplies audio to the abstractions in CallAgentService.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    private fun beginCall(number: String) {
        if (!hasPermission(Manifest.permission.CALL_PHONE)) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE))
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !isDefaultDialer()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                pendingStart = true
                roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            } else {
                statusMessage = "Default phone-app role is unavailable on this device."
            }
            return
        }
        placePreparedCall(number)
    }

    private fun placePreparedCall(number: String) {
        if (number.isBlank()) return
        try {
            val telecom = getSystemService(TelecomManager::class.java)
            val uri = Uri.fromParts("tel", number, null)
            telecom.placeCall(uri, Bundle())
            statusMessage = "CALLING — waiting for Android telephony to connect"
        } catch (e: SecurityException) {
            statusMessage = "ERROR — Android denied call placement. Make AI Call Agent the default phone app and allow phone permission."
        } catch (e: Exception) {
            statusMessage = "ERROR — call could not be started: ${e.message ?: "unknown error"}"
        }
    }

    private fun isDefaultDialer(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val roleManager = getSystemService(RoleManager::class.java) ?: return false
        return roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun readFirstPhoneNumber(contactUri: Uri): String? {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?",
            arrayOf(contactUri.lastPathSegment),
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

}
