package com.kalpittalele007.aicallagent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.TelecomManager
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

/** Immutable information supplied by the user for one call session. */
data class CallPlan(
    val person: String,
    val reason: String,
    val information: String,
    val instructions: String,
    val discloseAi: Boolean = true
)

enum class CallAgentState {
    IDLE, PREPARING, CALLING, CONNECTED, LISTENING, THINKING, SPEAKING, ENDING, ENDED, ERROR
}

data class ConversationTurn(val speaker: Speaker, val text: String)
enum class Speaker { USER, OTHER_PERSON, AI }

data class AiResponse(
    val text: String,
    val objectiveComplete: Boolean = false
)

/** Provider-neutral AI boundary. No credentials belong in this application. */
interface AiConversationEngine {
    suspend fun respond(plan: CallPlan, history: List<ConversationTurn>): AiResponse
}

/** Provider-neutral speech recognition boundary. */
interface SpeechRecognizer {
    fun start(onResult: (String) -> Unit, onError: (String) -> Unit)
    fun stop()
}

/** Provider-neutral text-to-speech boundary. */
interface SpeechSynthesizer {
    fun speak(text: String, onDone: () -> Unit, onError: (String) -> Unit)
    fun stop()
}

/** Provider-neutral call-control boundary. */
interface CallController {
    fun place(number: String): Result<Unit>
    fun end(call: Call): Result<Unit>
}

/** A deliberate placeholder until a real, authenticated AI provider is configured. */
class UnconfiguredAiConversationEngine : AiConversationEngine {
    override suspend fun respond(plan: CallPlan, history: List<ConversationTurn>): AiResponse {
        throw IllegalStateException("No AI provider is configured. The app must not pretend an AI response exists.")
    }
}

/** Android TTS implementation. It is suitable for previews/device audio, not as cellular-call uplink. */
class AndroidSpeechSynthesizer(context: Context) : SpeechSynthesizer {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.getDefault()
        }
    }

    override fun speak(text: String, onDone: () -> Unit, onError: (String) -> Unit) {
        if (!ready) {
            onError("Android text-to-speech is not ready.")
            return
        }
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "ai-call-agent-${System.currentTimeMillis()}")
        if (result != TextToSpeech.SUCCESS) onError("Android text-to-speech could not start.") else onDone()
    }

    override fun stop() { tts?.stop() }
}

/** Uses TelecomManager only for supported call termination. */
class TelecomCallController(private val context: Context) : CallController {
    override fun place(number: String): Result<Unit> = runCatching {
        val telecom = context.getSystemService(TelecomManager::class.java)
            ?: error("Telecom service is unavailable.")
        telecom.placeCall(android.net.Uri.fromParts("tel", number, null), Bundle())
    }

    override fun end(call: Call): Result<Unit> = runCatching {
        call.disconnect()
    }
}

class CallAgentService : InCallService() {
    private var activeCall: Call? = null
    private var state: CallAgentState = CallAgentState.IDLE
    private var plan: CallPlan? = null
    private val history = mutableListOf<ConversationTurn>()
    private var ai: AiConversationEngine = UnconfiguredAiConversationEngine()
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechSynthesizer: SpeechSynthesizer? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        speechSynthesizer = AndroidSpeechSynthesizer(applicationContext)
        plan = readPlan()
        publish(CallAgentState.IDLE, "IDLE — waiting for a prepared call")
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        activeCall = call
        val details = call.details
        val number = details?.handle?.schemeSpecificPart
        if (plan != null && (number == null || normalize(number) == normalize(plan!!.person))) {
            publish(CallAgentState.CALLING, "CALLING — Android is connecting the prepared call")
        }
        call.registerCallback(callCallback)
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(callCallback)
        if (activeCall == call) {
            activeCall = null
            publish(CallAgentState.ENDED, "ENDED — call session finished")
            clearStoredPlan()
        }
        super.onCallRemoved(call)
    }

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, stateValue: Int) {
            when (stateValue) {
                Call.STATE_DIALING, Call.STATE_CONNECTING -> publish(CallAgentState.CALLING, "CALLING — waiting for connection")
                Call.STATE_ACTIVE -> onConnected(call)
                Call.STATE_DISCONNECTED -> {
                    publish(CallAgentState.ENDED, "ENDED — Android reports the call has ended")
                    clearStoredPlan()
                }
                Call.STATE_RINGING -> publish(CallAgentState.CONNECTED, "CONNECTED — incoming ringing state is visible")
            }
        }
    }

    private fun onConnected(call: Call) {
        val currentPlan = plan ?: run {
            publish(CallAgentState.ERROR, "ERROR — no prepared call plan was found.")
            return
        }
        publish(CallAgentState.CONNECTED, "CONNECTED — call is active")

        // Android's ordinary InCallService APIs do not provide arbitrary access to the remote
        // cellular-call audio stream. Never switch to LISTENING or claim an AI conversation here.
        publish(
            CallAgentState.ERROR,
            "ERROR — Android does not expose cellular call audio to this app. The call remains under Android's supported telephony controls; live AI listening/speaking requires a supported audio/VoIP integration."
        )

        // The opening statement is generated deterministically from user-supplied data. It is
        // not described as an AI-generated answer and is not injected into the cellular call.
        val opening = generateOpeningStatement(currentPlan)
        history.add(ConversationTurn(Speaker.AI, opening))
    }

    fun generateOpeningStatement(plan: CallPlan): String {
        val identity = if (plan.discloseAi) "Hello. I am an AI call agent." else ""
        val reason = " I am calling because ${plan.reason}."
        return (identity + reason + " I will only use the information provided for this call and will ask for clarification when I do not know something.").trim()
    }

    fun terminateSession(): Result<Unit> {
        val call = activeCall ?: return Result.failure(IllegalStateException("No active call."))
        publish(CallAgentState.ENDING, "ENDING — requesting Android to end the call")
        return TelecomCallController(this).end(call).onSuccess {
            publish(CallAgentState.ENDED, "ENDED — session termination requested")
        }.onFailure {
            publish(CallAgentState.ERROR, "ERROR — Android did not allow the call to end: ${it.message}")
        }
    }

    private fun publish(newState: CallAgentState, message: String) {
        state = newState
        sendBroadcast(
            Intent(ACTION_STATUS).setPackage(packageName)
                .putExtra(EXTRA_STATE, newState.name)
                .putExtra(EXTRA_MESSAGE, message)
        )
    }

    private fun readPlan(): CallPlan? {
        val number = prefs.getString(KEY_PERSON, null) ?: return null
        return CallPlan(
            person = number,
            reason = prefs.getString(KEY_REASON, "").orEmpty(),
            information = prefs.getString(KEY_INFORMATION, "").orEmpty(),
            instructions = prefs.getString(KEY_INSTRUCTIONS, "").orEmpty(),
            discloseAi = prefs.getBoolean(KEY_DISCLOSE_AI, true)
        )
    }

    private fun clearStoredPlan() {
        prefs.edit().clear().apply()
        plan = null
        history.clear()
    }

    private fun normalize(value: String): String = value.filter { it.isDigit() }

    override fun onDestroy() {
        speechRecognizer?.stop()
        speechSynthesizer?.stop()
        if (activeCall != null) activeCall?.unregisterCallback(callCallback)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STATUS = "com.kalpittalele007.aicallagent.ACTION_STATUS"
        const val EXTRA_STATE = "state"
        const val EXTRA_MESSAGE = "message"
        private const val PREFS = "call_agent_session"
        private const val KEY_PERSON = "person"
        private const val KEY_REASON = "reason"
        private const val KEY_INFORMATION = "information"
        private const val KEY_INSTRUCTIONS = "instructions"
        private const val KEY_DISCLOSE_AI = "disclose_ai"

        fun prepareSession(context: Context, plan: CallPlan) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_PERSON, plan.person)
                .putString(KEY_REASON, plan.reason)
                .putString(KEY_INFORMATION, plan.information)
                .putString(KEY_INSTRUCTIONS, plan.instructions)
                .putBoolean(KEY_DISCLOSE_AI, plan.discloseAi)
                .apply()
            context.sendBroadcast(
                Intent(ACTION_STATUS).setPackage(context.packageName)
                    .putExtra(EXTRA_STATE, CallAgentState.PREPARING.name)
                    .putExtra(EXTRA_MESSAGE, "PREPARING — call plan stored for the supported Android call session")
            )
        }
    }
}
