# AI Call Agent

AI Call Agent is a compact Android application for preparing transparent AI-assisted phone-call sessions. The user supplies a person/phone number, a reason for the call, information the agent may use, and optional conversation instructions. The app prepares a call plan, uses supported Android telephony APIs to place and observe a call, and identifies the system as an AI agent when an opening statement is generated.

## Important current limitation

A normal Android application cannot assume access to the remote audio stream of an ordinary cellular call. `InCallService` exposes supported call state/control APIs, but it does **not** grant arbitrary capture of the other party's cellular-call audio. This project deliberately does not attempt to bypass Android security, use hidden APIs, secretly intercept calls, or capture protected call audio.

Therefore, the current initial project can:

- collect and validate a call plan;
- require the Android phone-app/default-dialer role before supported call control is used;
- request `CALL_PHONE` only when the user starts a call;
- request `READ_CONTACTS` only when the user chooses a contact;
- place a supported cellular call through `TelecomManager`;
- observe supported call states through `InCallService`;
- generate a deterministic opening statement from user-provided information;
- expose provider-neutral AI, speech recognition, speech synthesis, and call-control interfaces;
- fail clearly rather than pretending an AI response or call-audio access exists.

Actual live AI listening/speaking over a cellular call requires a supported telephony/VoIP architecture that provides the conversation audio to the corresponding adapters. The abstractions are intentionally ready for that integration without changing the UI contract.

## Architecture

The project intentionally has only two application Kotlin source files:

- `MainActivity.kt` — Jetpack Compose UI, validation, permission handling, contact selection, default-dialer role request, call preparation, and status display.
- `CallAgentService.kt` — `InCallService`, call-plan model, conversation state, AI/speech/call interfaces, opening statement generation, supported call-state handling, and session termination.

Supporting Android files contain only build/manifest/resources/workflow configuration.

### AI provider boundary

`AiConversationEngine` is the provider-neutral interface. The included `UnconfiguredAiConversationEngine` intentionally fails instead of inventing a response. A future provider adapter should:

1. receive the supplied `CallPlan` and conversation history;
2. authenticate using credentials stored outside source control;
3. return a structured `AiResponse`;
4. never manufacture unknown facts;
5. signal objective completion when appropriate.

No API key, password, token, or private credential is included in this repository.

### Speech boundaries

`SpeechRecognizer` and `SpeechSynthesizer` isolate speech technology from the conversation logic. An Android TTS implementation is included for device-side speech output/preview, but it is **not** treated as a cellular-call uplink. A future supported audio/VoIP implementation can provide the actual conversation audio path.

### Call boundary

`CallController` isolates supported Android call placement/termination. `CallAgentService` uses `InCallService` to receive call lifecycle callbacks and never attempts unsupported audio interception.

## Call states

The application models:

`IDLE → PREPARING → CALLING → CONNECTED → LISTENING → THINKING → SPEAKING → ENDING → ENDED`

and `ERROR` for failures. With an ordinary cellular call, the service intentionally stops at `CONNECTED`/`ERROR` when it detects that the required remote audio path is unavailable; it does not falsely enter `LISTENING`, `THINKING`, or `SPEAKING`.

## Permissions

Only permissions that are actually used by the current implementation are declared/requested:

- `CALL_PHONE` — requested when the user starts a phone call.
- `READ_CONTACTS` — requested only when the user chooses a contact so the selected contact's phone number can be read.

`READ_PHONE_STATE` is not required by the current `InCallService` implementation and is therefore not requested. `RECORD_AUDIO` is also not requested because the current cellular-call path deliberately does not attempt to capture protected call audio. A future supported audio implementation may require a separately justified microphone permission.

## Default phone app / telephony requirements

Android requires supported call-management functionality to respect the platform's telephony roles and permissions. AI Call Agent declares the required `InCallService` and `ACTION_DIAL` components so it can request the default phone-app role where the device supports it.

The exact role and telephony behavior can vary by Android release, manufacturer, carrier, and device. The app never assumes that a third-party application can obtain arbitrary cellular-call audio.

## Build locally

Requirements:

- Android Studio with Java 17 support, or a Java 17 JDK;
- Android SDK Platform 35;
- Gradle wrapper included in the repository.

Build the debug APK:

```bash
./gradlew :app:assembleDebug --no-daemon
```

The APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

The repository contains `.github/workflows/android.yml`. On push, pull request, or manual dispatch it:

1. runs on Ubuntu;
2. checks out the repository;
3. installs Java 17;
4. configures Gradle;
5. builds the debug APK with `--no-daemon`;
6. uploads `app-debug.apk` as the `ai-call-agent-debug-apk` artifact.

After a workflow succeeds, open the workflow run in GitHub and download the artifact from the **Artifacts** section.

## Security considerations

- Do not commit API keys or other credentials.
- Use Android Keystore, encrypted storage, or a server-side secret boundary for any future credentials as appropriate.
- Do not send more call context to an AI provider than the user intended.
- Do not claim facts that were not supplied by the user or returned by the configured AI provider.
- The AI identity disclosure is enforced in the UI and the call-plan model.
- Do not add hidden call recording, protected-audio interception, accessibility abuse, root-only hooks, or private Android APIs.

## AI identity disclosure

The agent is designed to identify itself as an AI agent. The disclosure cannot be disabled by the current UI. The generated opening statement explicitly states that the caller is an AI call agent and says that it will ask for clarification instead of inventing unknown information.

## Repository

This project is structured to be uploaded directly to the requested GitHub repository:

`https://github.com/kalpittalele007-max/AI-Call-Agent.git`
